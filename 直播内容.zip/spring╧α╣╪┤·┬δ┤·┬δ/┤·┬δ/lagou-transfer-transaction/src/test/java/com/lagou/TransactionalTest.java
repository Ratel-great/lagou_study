package com.lagou;


import com.lagou.edu.service.TransferService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 * 事务传播行为测试类
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("classpath:applicationContext.xml")
public class TransactionalTest {

    @Autowired
    TransferService transferService;

    @Test
    public void tansactionTest1() throws Exception {
        transferService.transfer("622202100001", "622202100002", 100);
    }


}
