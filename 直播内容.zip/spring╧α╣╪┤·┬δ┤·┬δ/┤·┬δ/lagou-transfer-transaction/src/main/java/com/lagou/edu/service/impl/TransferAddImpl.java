package com.lagou.edu.service.impl;


import com.lagou.edu.dao.AccountDao;
import com.lagou.edu.pojo.Account;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Service
public class TransferAddImpl {
    @Autowired
    AccountDao accountDao;

    /**
     * 向账户加钱操作
     *
     * @param account
     * @param money
     */
    @Transactional(propagation = Propagation.REQUIRED)
    public void transferAdd(Account account, int money) throws Exception {
        account.setMoney(account.getMoney() + money);
        accountDao.updateAccountByCardNo(account);
    }

}
