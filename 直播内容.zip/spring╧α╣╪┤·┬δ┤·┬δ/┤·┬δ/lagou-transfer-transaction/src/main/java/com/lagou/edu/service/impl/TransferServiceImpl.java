package com.lagou.edu.service.impl;

import com.lagou.edu.dao.AccountDao;
import com.lagou.edu.pojo.Account;
import com.lagou.edu.service.TransferService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;


/**
 * @author 应癫
 */
@Service("transferService")
public class TransferServiceImpl implements TransferService {


    @Autowired
    @Qualifier("accountDao")
    private AccountDao accountDao;

    @Autowired
    TransferAddImpl transferAdd;

    @Autowired
    TransferSubImpl transferSub;

    @Override
    //@Transactional
    public void transfer(String fromCardNo, String toCardNo, int money) throws Exception {
        /*Account from = accountDao.queryAccountByCardNo(fromCardNo);
        Account to = accountDao.queryAccountByCardNo(toCardNo);

        *//*from.setMoney(from.getMoney() - money);
        to.setMoney(to.getMoney() + money);

        accountDao.updateAccountByCardNo(to);
        accountDao.updateAccountByCardNo(from);*//*
        transferAdd.transferAdd(to, money);// 1-5 保存  6 日志记录数据库
        try {
            transferSub.transferSub(from, money);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }*/
        this.transfer1("1", "!", 11);

    }

    @Transactional
    public void transfer1(String fromCardNo, String toCardNo, int money) throws Exception {
        Account from = accountDao.queryAccountByCardNo(fromCardNo);
        Account to = accountDao.queryAccountByCardNo(toCardNo);

        /*from.setMoney(from.getMoney() - money);
        to.setMoney(to.getMoney() + money);

        accountDao.updateAccountByCardNo(to);
        accountDao.updateAccountByCardNo(from);*/
        transferAdd.transferAdd(to, money);// 1-5 保存  6 日志记录数据库
        try {
            transferSub.transferSub(from, money);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

    }


}
