package com.lagou.edu.service.impl;


import com.lagou.edu.dao.AccountDao;
import com.lagou.edu.pojo.Account;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Service
public class TransferSubImpl {
    @Autowired
    AccountDao accountDao;

    /**
     * 向账户加钱操作
     *
     * @param account
     * @param money
     */
    @Transactional(propagation = Propagation.NESTED)
    public void transferSub(Account account, int money) throws Exception {
        account.setMoney(account.getMoney() - money);
        accountDao.updateAccountByCardNo(account);
        int i = 10 / 0;//模拟异常
    }

}
